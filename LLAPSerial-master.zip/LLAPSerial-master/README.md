This Arduino library is under development.
It is designed to assist the user in implementing a LLAP device using the Arduino development environment.