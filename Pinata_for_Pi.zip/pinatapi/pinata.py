#!/usr/bin/env python

import sys
import serial
import RPi.GPIO as GPIO

#devid to listen to 
devid = 'XX'

baud = 9600
port = '/dev/ttyAMA0'

ser = serial.Serial(port, baud)
ser.timeout = 0

ser.write('a' + devid + 'STARTED--')


while 1:
        if ser.inWaiting() >= 12:
                if ser.read() == 'a':
                        #llap msg start
                        msg = 'a'
                        if ser.read(2) == devid:
                                #yes its for us
                                llapMsg = ser.read(9)
                                #got nine dat bytes
                                reply = 'a' + devid
                                if llapMsg == 'HELLO----':
                                        #echo back
                                        reply += 'HELLO---'
                                else :
                                        ioNumber = bytes(llapMsg[0:3])
                                        reply += llapMsg[0:3]
                                        llapMsg = llapMsg[3:]
                                        
                                        if llapMsg == 'INPUT-':
                                           GPIO.setup(ioNumber, GPIO.IN)
                                           reply += llapMsg
                                        elif llapMsg == 'OUTPUT':
                                             GPIO.setup(ioNumber, GPIO.OUT)
                                             reply += llapMsg
                                        elif llapMsg == 'HIGH--':
                                             GPIO.output(ioNumber, True)
                                             reply += llapMsg
                                        elif llapMsg == 'LOW---':
                                             GPIO.output(ioNumber, False)
                                             reply += llapMsg
                                        elif llapMsg == 'READ--':
                                             state = GPIO.input(ioNumber)
                                             if state == 1:
                                                reply += 'HIGH'
                                             else: #state == 0
                                                reply += 'LOW'
                                        else:
                                                reply = 'a' + devid + 'ERROR----'
                                        
                                                
                                while len(reply) < 12:
                                        reply += '-'
                                
                                ser.write(reply)


