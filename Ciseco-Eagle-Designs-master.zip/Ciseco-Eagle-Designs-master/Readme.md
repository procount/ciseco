This repository contains the schematic and pcb files for some Ciseco products

Each product is in its own folder and there may be any combination of files from.
* PDF schematic
* Eagle schematic
* Eagle PCB
* Gerbers

If you wish to download all the files either use git clone

    $ git clone https://github.com/CisecoPlc/Ciseco-Eagle-Designs.git

or download them all as zip file

https://github.com/CisecoPlc/Ciseco-Eagle-Designs/archive/master.zip

To download individual files navigate to the file and select 'Raw' from the toolbar, then use your browsers File->Save As option
